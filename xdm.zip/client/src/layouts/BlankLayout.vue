<template>
  <main class="container my-24 px-6 mx-auto">
    <slot />
  </main>
</template>
