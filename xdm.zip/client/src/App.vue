<script setup lang="ts">
import { RouterView } from "vue-router";
import Debug from "@/components/Debug.vue";
</script>

<template>
  <Debug />
  <RouterView />
</template>
