<template>
  <RouterLink to="/" class="mb-3 text-4xl font-black w-fit hover:bg-white hover:text-black no-underline">xdm</RouterLink>
</template>
